import 'package:flutter/material.dart';

void main() => runApp(Atividade());

class Atividade extends StatelessWidget {
  const Atividade({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Atividade',
      home: Tela1(), // Define a Tela1 como a tela inicial
    );
  }
}

class Tela1 extends StatelessWidget {
  const Tela1({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
        backgroundColor: Colors.blue,
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Tela Inicial",
              style: TextStyle(
                fontSize: 50,
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Tela2()),
                  ),
                  child: Text(
                    "Formulário",
                    style: TextStyle(
                      fontSize: 20,
                    ),
                  ),
                ),
                ElevatedButton(
                  onPressed: () {},
                  child: Text(
                    "Resumo",
                    style: TextStyle(
                      fontSize: 20,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class Tela2 extends StatefulWidget {
  const Tela2({super.key});

  @override
  State<Tela2> createState() => _Tela2State();
}

class _Tela2State extends State<Tela2> {
  bool aceitarTermos = false;
  String? generoMusical;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Formulário'),
        backgroundColor: Colors.blue,
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CheckboxListTile(
              title: Text("Aceitar Termos"),
              value: aceitarTermos,
              onChanged: (bool? value) {
                setState(() {
                  aceitarTermos = value!;
                });
              },
            ),
            RadioListTile<String>(
              title: Text('Rock'),
              value: 'Rock',
              groupValue: generoMusical,
              onChanged: (String? value) {
                setState(() {
                  generoMusical = value;
                });
              },
            ),
            RadioListTile<String>(
              title: Text('Jazz'),
              value: 'Jazz',
              groupValue: generoMusical,
              onChanged: (String? value) {
                setState(() {
                  generoMusical = value;
                });
              },
            ),
            RadioListTile<String>(
              title: Text('Pop'),
              value: 'Pop',
              groupValue: generoMusical,
              onChanged: (String? value) {
                setState(() {
                  generoMusical = value;
                });
              },
            ),
            ElevatedButton(
              onPressed: () {
                // Navega para a tela de resumo, passando os dados
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => Tela3(
                      aceitarTermos: aceitarTermos,
                      generoMusical: generoMusical,
                    ),
                  ),
                );
              },
              child: Text("Salvar e Ir para o Resumo"),
            ),
          ],
        ),
      ),
    );
  }
}

class Tela3 extends StatelessWidget {
  final bool aceitarTermos;
  final String? generoMusical;

  const Tela3({
    super.key,
    required this.aceitarTermos,
    required this.generoMusical,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Resumo'),
        backgroundColor: Colors.blue,
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Aceitou os Termos: ${aceitarTermos ? "Sim" : "Não"}',
              style: TextStyle(fontSize: 20),
            ),
            Text(
              'Gênero Musical: ${generoMusical ?? "Nenhum selecionado"}',
              style: TextStyle(fontSize: 20),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context); // Volta para a Tela1
              },
              child: Text("Voltar para o Início"),
            ),
          ],
        ),
      ),
    );
  }
}
